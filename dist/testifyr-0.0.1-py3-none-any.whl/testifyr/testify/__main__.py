from .testify import main

if __name__ == "__main__":
    main()  # Ensure main is defined in testify.py or here
