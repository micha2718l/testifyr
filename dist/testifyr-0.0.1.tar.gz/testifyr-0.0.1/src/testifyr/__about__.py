# SPDX-FileCopyrightText: 2024-present micha2718l <micha2718l@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
